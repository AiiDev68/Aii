module.exports = {
  tokens: "8287695993:AAGH8_330XZREK2hgLgd4xtnKri-MHnAeIA",
  owner: "6399021348",
  port: "4009",
  ipvps: "167.71.223.75"
};